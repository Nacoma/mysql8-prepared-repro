OPTIMIZE TABLE _line_items;
OPTIMIZE TABLE _registrations;
OPTIMIZE TABLE _orders;
OPTIMIZE TABLE _registrations;
OPTIMIZE TABLE _registrants;
